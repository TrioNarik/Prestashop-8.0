<?php

global $_MODULE;
$_MODULE = [];
// config
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_5623f4a1b109d6c7092a51e2636a6fa5'] = 'MKD - Wyróżnione kategorie na stronie głównej';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_743c58f625be56a3c31f603047eacfad'] = 'Wyróżnione Kategorie produktów dla danego sklepu z dynamicznym licznikiem aktywnych produktów w wybranych kategoriach';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_c61562f9eb55de3680f8ed5ffedb96db'] = 'Czy na pewno chcesz odinstalować ten moduł? Wszystkie dane zostaną usunięte.';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_c3c39ab8e5f3c3ba8b6cadf643f3ff85'] = 'Kategoria została pomyślnie usunięta z modułu MKD';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_0dffafedf80e39d158fed5ccd528ffb4'] = 'Nie znaleziono kategorii w module MKD.';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_0d33179ffbdd55fc970452c6aa1d53c3'] = 'Ustawienia modułu zostały zapisane.';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_b42d42c5a64f8bd6d007dcd17b8a773a'] = 'Wybierz kategorie do wyświetlenia na stronie głównej:';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_092c36c82a35384d68c6d1085bdae55a'] = 'Nagłówek:';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_d0759c16df62a0b5726f8506fdfb86dd'] = 'Wprowadź nagłówek dla sekcji';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_234078adec0a64008b6ae77653776cfa'] = 'Krótki opis:';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_303d0d899154c60f35be9c14d0cd52d7'] = 'Wprowadź opcjonalnie dodatkowy opis';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_55466b3957173dcb15075b0375235e7d'] = 'Wybierz kategorie:';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_a4bbbb5bc3734b72b62e38f34f642497'] = ' Zaznaczone kategorie z listy zostaną wyświetlone na stronie głównej';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz ustawienia';
// template
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_62f5d708d6ad1fa1ddd9429a65cccbea'] = 'Wszystkie kategorie';
//tempalte => pluralize
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_09dc02ecbb078868a3a86dded030076d'] = 'Brak produktów';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_702085cd8b96c1e778c9e59ffba0394d'] = '1 produkt';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_78de86a20eb025cb0250bb9ae048678b'] = '%count% produkty';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_378376cbe5b75507660fffbf1d35d429'] = '%counts% produktów';
// form-tools
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_9af49283c248b68a740606dcb23033bd'] = 'Dostępna wersja PRO:';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_3c6392d21eded83348fcd9ba6fbf3784'] = 'Pobierz teraz';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_b0d0ad9860e87e23de571b1e45f6e947'] = 'Sprawdź także inne przydatne moduły:';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_97fed0706aeabc1101fedfe7b6b729a9'] = 'Pobrań:';
$_MODULE['<{mkd_categories_homepage}prestashop>mkd_categories_homepage_8ae4254b197adafcf35480ce56eb2f76'] = 'Możesz pomóc w rozwoju, przekazując darowiznę:';

