<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class MKD_categories_homepage extends Module
{
    // ==========================================
    const TABLE     = 'mkd_categories_homepage';
    const NAME      = 'MKD - Featured categories on the Home Page';
    const DESC      = 'Featured Categories with a dynamic counter of active products in selected categories';
    const VERSION   = '2.9.6';
    // ==========================================


    public function __construct()
    {
        $this->name = self::TABLE;
        $this->tab = 'front_office_features';
        $this->version = self::VERSION;
        $this->author = 'MKDnet';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->module_key = '7753977150bf1a1a1a58b34394a7b2d9';

        parent::__construct();

        $this->displayName = $this->l(self::NAME);
        $this->description = $this->l(self::DESC);
        $this->image = 'logo.png';

        $this->bootstrap = true;
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall this module? All data will be deleted.');
    }

    private function createTable()
    {
        // Utworzyć tabelę w bazie danych
        // ==============================
        $db = Db::getInstance();

        $query = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.self::TABLE.'` (
            `lang` VARCHAR(5) NOT NULL,
            `title` VARCHAR(255) NOT NULL,
            `legend` VARCHAR(255) NOT NULL,
            `categories` TEXT NOT NULL,
            PRIMARY KEY (`lang`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';
        $db->execute($query);
    }

    public function install()
    {
        $this->createTable();
        
        return parent::install() 
            && $this->registerHook('displayHome')
            && $this->registerHook('actionCategoryDelete')
        ;
    }

    private function deleteTable()
    {
        // Usunąć tabelę z bazy danych
        $db = Db::getInstance();

        $query = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.self::TABLE.'`';

        $db->execute($query);
    }

    public function uninstall()
    {
        $this->deleteTable();
        return parent::uninstall();
    }

    public function hookActionCategoryDelete($params)
    {
        // Pobierz ID usuniętej kategorii
        $categoryId = (int) $params['category']->id;

        // Wykonaj odpowiednie akcje po usunięciu kategorii

        // Pobierz zapisane kategorie z tabeli modułu
        $query = 'SELECT `categories` FROM `' . _DB_PREFIX_ . self::TABLE . '`';
        $categories = Db::getInstance()->getValue($query);

        if ($categories) {
            $categoryArray = unserialize($categories);

            // Sprawdź czy ID usuniętej kategorii istnieje w tablicy
            $index = array_search($categoryId, $categoryArray);
            if ($index !== false) {
                // Usuń ID kategorii z tablicy
                unset($categoryArray[$index]);

                // Zresetuj indeksy tablicy
                $categoryArray = array_values($categoryArray);

                // Zaktualizuj wartość w bazie danych
                $query = 'UPDATE `' . _DB_PREFIX_ . self::TABLE . '` SET `categories` = "' . serialize($categoryArray) . '"';
                Db::getInstance()->execute($query);

                // Powodzenie usuwania
                $this->context->controller->confirmations[] = $this->l('The category has been successfully removed from the MKD module');
            } else {
                // Błąd usuwania
                $this->context->controller->errors[] = $this->l('No category found in the MKD module.');
            }
        }

        $this->clearCache(); // Wyczyszczenie cache'u

        // Wyświetlenie komunikatu dla administratora
        $message = 'Category ID ' . $categoryId . ' has been deleted.';
        $this->context->controller->confirmations[] = $message;
    }



    public function hookDisplayHome($params)
    {
        // Wyświetlanie kategorii na stronie głównej
        $selectedCategories = array();
        $currentLangCode = Context::getContext()->language->iso_code;
        // Bieżący ID sklepu
        $currentShopId = Context::getContext()->shop->id;

        $query = 'SELECT `title`, `legend`, `categories` FROM `'._DB_PREFIX_.self::TABLE.'` WHERE `lang` = "'.pSQL($currentLangCode).'"';
        $results = Db::getInstance()->getRow($query);

        if ($results) {
            $title = $results['title'];
            $legend = $results['legend'];
            $selectedCategoryIds = unserialize($results['categories']);
            
            // Zlicz ilość zaznaczonych kategorii
            $selectedCategoryCount = count($selectedCategoryIds);

            foreach ($selectedCategoryIds as $categoryId) {
                $category = new Category($categoryId, $currentLangCode, $currentShopId);

                if (isset($category->id) && $category->active) {

                    // Licznik produktów w kategorii
                    $productCount = Db::getInstance()->getValue('
                                    SELECT COUNT(*) 
                                    FROM `'._DB_PREFIX_.'category_product` cp
                                    LEFT JOIN `'._DB_PREFIX_.'product` p ON (cp.`id_product` = p.`id_product`)
                                    WHERE cp.`id_category` = '.(int)$category->id.' AND p.`active` = 1'
                                );

                    $categoryData = array(
                        'id' => $category->id,
                        'name' => $category->name,
                        'url' => $category->getLink(),
                        'imagePath' => _THEME_CAT_DIR_ . $category->getLinkRewrite($category->id, $currentLangCode) . $category->id . '.jpg',                       
                        'description' => $category->description,
                        'productCount' => $productCount
                    );

                    $selectedCategories[] = $categoryData;
                }
            }
        }

        $this->context->smarty->assign(array(
            'selectedCategories' => $selectedCategories,
            'title' => $title,
            'legend' => $legend,
            'selectedCategoryCount' => $selectedCategoryCount, // Ilość zaznaczonych kategorii
        ));

        return $this->display(__FILE__, 'views/templates/hook/categories_homepage.tpl');
    }


    // ==================================================================
    // KONFIGURACJA =========== Odpowiada za opcje 'Konfiguruj'==========
    // ==================================================================

    public function getContent()
    {
        $output = '';

        if (Tools::isSubmit('submit'.$this->name)) {
            $this->postProcess();
            $output .= $this->displayConfirmation($this->l('The module settings have been saved.'));
        }

        $output .= $this->renderForm();

        return $output;
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submit'.$this->name)) {
            $languages = Language::getLanguages(true);

            foreach ($languages as $language) {
                $title = Tools::getValue('title_'.$language['id_lang']);
                $legend = Tools::getValue('legend_'.$language['id_lang']);
                $categories = Tools::getValue('selected_categories');

                // Sprawdź, czy wiersz o danej wartości lang istnieje w tabeli
                $existingRow = Db::getInstance()->getRow('
                    SELECT * FROM `'._DB_PREFIX_.self::TABLE.'`
                    WHERE `lang` = "'.pSQL($language['iso_code']).'"
                ');

                if ($existingRow) {
                    // Aktualizuj istniejący wiersz
                    $data = array(
                        'title' => $title,
                        'legend' => $legend,
                    );

                    // Sprawdź, czy kategorie są zaznaczone
                    if (!empty($categories)) {
                        $data['categories'] = serialize($categories);
                    } else {
                        $data['categories'] = ''; // Ustaw puste wartości dla kategorii
                    }

                    Db::getInstance()->update(self::TABLE, $data, '`lang` = "'.pSQL($language['iso_code']).'"');
                    
                } else {
                    // Dodaj nowy wiersz
                    $data = array(
                        'lang' => $language['iso_code'],
                        'title' => $title,
                        'legend' => $legend,
                    );

                    // Sprawdź, czy kategorie są zaznaczone
                    if (!empty($categories)) {
                        $data['categories'] = serialize($categories);
                    } else {
                        $data['categories'] = ''; // Ustaw puste wartości dla kategorii
                    }

                    Db::getInstance()->insert(self::TABLE, $data);
                }
            }
        }
    }


    // ==================================================================
    // FORMULARZ ========================================================
    // ==================================================================
    public function generateForm()
    {
        // [opcjonalnie] "module_dir", aby można było jej użyć w szablonie w celu dostępu do ścieżki modułu IMG/CSS itd.

        $formFooter = $this->context->smarty->fetch($this->local_path . 'views/templates/admin/display_form_protext.tpl');
        $this->context->smarty->assign(array(
            'module_dir' => $this->_path,
            'promote' => $formFooter,
        ));

        $form = $this->renderForm() . $this->context->smarty->getTemplateVars('promote');

        return $form;
    }

    public function renderForm()
    {
        $defaultLang = (int) Configuration::get('PS_LANG_DEFAULT');
        $languages = Language::getLanguages(true);
        
        $fieldsForm = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Select categories to display on the home page:'),
                    'icon' => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('Header:'),
                        'name' => 'title',
                        'lang' => true,
                        'desc' => $this->l('Enter a heading for the section'),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Short description:'),
                        'name' => 'legend',
                        'lang' => true,
                        'desc' => $this->l('Optionally enter an additional description'),
                    ),
                    array(
                        'type' => 'categories',
                        'label' => $this->l('Select categories:'),
                        'name' => 'selected_categories',
                        'required' => true,
                        'tree' => array(
                            'id' => 'categories-tree',
                            'use_search' => false,
                            'selected_categories' => $this->getSelectedCategories(),
                            'root_category' => 0,
                            'use_checkbox' => true,
                            'use_context' => true,
                            'expand_all' => true,
                        ),
                        'desc' => $this->l('The selected categories will be displayed on the Home page'),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );

        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
        $helper->title = $this->displayName;
        $helper->default_form_language = $defaultLang;
        $helper->allow_employee_form_lang = $defaultLang;
        $helper->show_toolbar = true;
        $helper->toolbar_scroll = true;
        $helper->submit_action = 'submit'.$this->name;

        // zwraca listę aktywnych języków
        $languages = $this->context->controller->getLanguages();
        $helper->languages = $languages;

        // Pobierz wartości tytułu i legendy dla każdego języka
        foreach ($languages as $language) {
            $langId = $language['id_lang'];

            $title = $this->getFieldValue('title', $langId);
            $legend = $this->getFieldValue('legend', $langId);

            $helper->fields_value['title'][$langId] = $title;
            $helper->fields_value['legend'][$langId] = $legend;
        }

        $this->fields_form = array($fieldsForm);

        return $helper->generateForm($this->fields_form);
        
    }



    // Pobierz wartość pola dla danego języka
    private function getFieldValue($fieldName, $idLang)
    {
        $currentLangIso = Language::getIsoById((int) $idLang);
        $result = Db::getInstance()->getValue('
            SELECT `'.$fieldName.'`
            FROM `'._DB_PREFIX_.self::TABLE.'`
            WHERE `lang` = "'.pSQL($currentLangIso).'"
        ');
    
        return $result;
    }
    

    // Pobierz identyfikatory wybranych kategorii
    private function getSelectedCategories()
    {
        $selectedCategories = array();
        $currentLangId = Context::getContext()->language->iso_code;
    
        $query = 'SELECT `categories` FROM `'._DB_PREFIX_.self::TABLE.'` WHERE `lang` = "'.pSQL($currentLangId).'"';
        $result = Db::getInstance()->getValue($query);
    
        if ($result) {
            $selectedCategories = unserialize($result);
        }
    
        return $selectedCategories;
    }

}
