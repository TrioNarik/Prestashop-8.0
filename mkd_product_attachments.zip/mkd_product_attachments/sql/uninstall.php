<?php

$sql = [];
// -- Usuwanie tabel
$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'mkd_product_attachments_programs`';
$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'mkd_product_attachments_hooks`';
$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'mkd_product_attachments_formats`';
// Klucze obce z .._types(!)
$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'mkd_product_attachments_types_lang`'; 
$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'mkd_product_attachments_types_shop`';
$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'mkd_product_attachments_types`';

$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'mkd_product_attachments`';

foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}