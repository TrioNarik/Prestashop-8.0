<?php
/*
* Instaluje podstawowe dane: hooki i możliwe formatach załaczników z JSON
*/

class MKDInstallerDefaultData
{
    protected $moduleName;

    public function __construct($moduleName)
    {
        $this->moduleName = $moduleName;
    }

    public function installDefaultData($dataList, $table, $file = 'SampleDataDefault')
    {
        // Pobierz podstawowe dane z JSON
        $jsonPath = _PS_MODULE_DIR_ . $this->moduleName . '/' . $file . '.json';
        $jsonContent = file_get_contents($jsonPath);
        $jsonData = json_decode($jsonContent, true);

        if (!isset($jsonData[$dataList])) {
            return false; // Nieznana lista danych
        }
        
        $idShop = (int) Context::getContext()->shop->id;
        $defaultLangIso = Context::getContext()->language->iso_code;
        
        foreach ($jsonData[$dataList] as $row) {
            $value = pSQL($row['value']);
            $name = pSQL(isset($row['name'][$defaultLangIso]) ? $row['name'][$defaultLangIso] : $row['name']['en']);
            
            $data = array(
                'shop_id' => $idShop,
                'lang_iso' => $defaultLangIso,
                'value' => $value,
                'name' => $name,
            );
            
            Db::getInstance()->insert($table, $data);
            
        }
        
        return true;
    }
    
}


