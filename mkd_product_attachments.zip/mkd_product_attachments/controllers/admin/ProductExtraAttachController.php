<?php
/*
* 
*/


if (!defined('_PS_VERSION_')) {
    exit;
}

class ProductExtraAttachController extends ModuleAdminController
{
    public function __construct()
    {

        // Ustawienia kontrolera
        parent::__construct();

    }


    public function initForm($product_ID)
    {
    
        if ((int)$product_ID <= 0) {
            return;
        }
        
        // Załaduj Model
        require_once(_PS_MODULE_DIR_. _MKD_NAME_ .'/models/MKDProductAttachmentsModel.php');
        
        $model = new MKDProductAttachmentsModel();
        
        // Pobierz dostępne grupy załączników
        $shopId = Context::getContext()->shop->id;
        $languageId = Context::getContext()->language->id;
        $availableGroups = $model->getAvailableAttachmentGroups($shopId, $languageId);

        // Pobierz załączniki dla produktu
        $productAttachments = $model->getProductAttachmentsByProductId($product_ID);

        // Link do konfiguracji modułu
        $linkToAddNewGroup   = $this->context->link->getAdminLink('AdminModules', true);
        $linkToAddNewGroup  .= '&configure=mkd_product_attachments';

        // Ścieżki do plików
        $jsFilePath = __PS_BASE_URI__ . 'modules/' . _MKD_NAME_ ;
        $uploadPath = __PS_BASE_URI__ . 'upload/attachments/product_' .$product_ID;
        
        // Przekaż dane do szablonu
        $smarty = $this->context->smarty;
        $smarty->assign([
            'jsFilePath'            => $jsFilePath,
            'uploadPath'            => $uploadPath,
            'linkToAddNewGroup'     => $linkToAddNewGroup,
            'shopId'                => $shopId,
            'productId'             => $product_ID,
            'availableGroups'       => $availableGroups,
            'productAttachments'    => $productAttachments
        ]);
        
    }

    // Obsługa żądania AJAX

    // =================================
    // Dodawanie załącznika ============
    // =================================
    public function ajaxProcessAddAttachment()
    {

        // Załaduj Model
        require_once(_PS_MODULE_DIR_ . _MKD_NAME_ . '/models/MKDProductAttachmentsModel.php');

        // Utwórz instancję modelu
        $model = new MKDProductAttachmentsModel();

        // Pobierz aktualną datę i godzinę
        $currentDateTime = date('Y-m-d H:i:s');

        // Pobierz dane z AJAX
        $id_shop        = (int)Tools::getValue('shopId', Configuration::get('PS_SHOP_DEFAULT'));
        $product_id     = (int)Tools::getValue('productId');
        $type_id        = (int)Tools::getValue('groupId');
        $file_name      = Tools::getValue('attachmentName');

        $attachmentFile = $_FILES['attachmentFile'] ?? null;
        // if (isset($_FILES['attachmentFile'])) {
        //     $attachmentFile = $_FILES['attachmentFile'];
        // } else {
        //     $attachmentFile = null;
        // }
        $attachmentURL = Tools::getValue('attachmentURL') ? filter_var(Tools::getValue('attachmentURL'), FILTER_VALIDATE_URL) : null;
        
        $comment        = Tools::getValue('attachmentComment');
        $data_add       = $currentDateTime;
        $data_upd       = $currentDateTime;
        $active         = (int)Tools::getValue('active');


        // Pobierz Format pliku (value) dla danej grupy załączników w ścieżce 'upload_dir'
        $language_ID = Context::getContext()->language->id;
        $attachFormat = $model->getAttachmentFormatByTypeId($type_id, $language_ID);

        // Katalog docelowy, gdzie będą przechowywane załączniki
        $uploadDirectory = _PS_UPLOAD_DIR_ . 'attachments/product_' . $product_id . '/' . $attachFormat . '/';

        // Pobierz najwyższą position dla danej Grupy i dodaj następną
        $maxPosition = (int)Db::getInstance()->getValue('SELECT MAX(`position`) FROM `' . _DB_PREFIX_ . MKDProductAttachmentsModel::$definition['table'] . '` WHERE `type_id` = ' . (int)$type_id);

        // Ustaw dane w Modelu
        $model->id_shop     = $id_shop;
        $model->product_id  = $product_id;
        $model->type_id     = $type_id;
        $model->file_name   = $file_name;
        $model->comment     = $comment;
        $model->position    = $maxPosition + 1;
        $model->data_add    = $data_add;
        $model->data_upd    = $data_upd;
        $model->active      = $active;

        // Zapisz plik
        if (Tools::getValue('action') === 'addAttachment') {

            if (!file_exists($uploadDirectory)) {
                mkdir($uploadDirectory, 0777, true);
            }

            // Walidacja pliku/URL
            if ($attachmentFile && $attachmentFile['error'] === UPLOAD_ERR_OK) {

                // Data pliku
                $currentTimestamp = time();
                $currentDate = date('d-m-Y');
                $fileName = $currentDate . '_' . $currentTimestamp . '_' . $attachmentFile['name'];

                // Ścieżka docelowa
                $targetPath = $uploadDirectory . $fileName;

                // Przesuń plik z folderu tymczasowego do docelowego folderu
                if (move_uploaded_file($attachmentFile['tmp_name'], $targetPath)) {
                    
                    // Plik został zapisany pomyślnie
                    $model->file_url = $fileName;

                } else {
                    // Wystąpił błąd podczas zapisywania pliku
                    $response = [
                        'success' => false,
                        'message' => Context::getContext()->getTranslator()->trans('There was an error saving')
                    ];
                }

            } elseif ($attachmentURL) {
                // Przesłano adres URL
                
                $model->file_url = $attachmentURL;
                
            }    

            // Zapisz załącznik
            $result = $model->add();

            if ($result) {

                // Pobierz liczbę plików dla danej Grupy załączników w tabeli ..types_shop
                $currentFilesCount = (int) Db::getInstance()->getValue('
                SELECT `files` 
                FROM `' . _DB_PREFIX_ . 'mkd_product_attachments_types_shop` 
                WHERE `type_id` = ' . $model->type_id . ' 
                AND `id_shop` = ' . $model->id_shop
                );

                // Zwiększ liczbę plików o 1
                $newFilesCount = $currentFilesCount + 1;

                // Zaktualizuj Counter plików w danej Grupie
                Db::getInstance()->update(
                    'mkd_product_attachments_types_shop',
                    ['files' => $newFilesCount],
                    'type_id = ' . $model->type_id . ' AND `id_shop` = ' . $model->id_shop
                );

                // Wyświetlić powiadomienie w Ajax
                $response = [
                    'success' => true,
                    'message' => Context::getContext()->getTranslator()->trans('The new attachment has been saved to the Group:') . $type_id
                ];

            } else {
                // Wystąpił błąd podczas zapisywania załącznika
                $response = [
                    'success' => false,
                    'message' => Context::getContext()->getTranslator()->trans('There was an error saving')
                ];
            }

            // Zwróć odpowiedź JSON
            header('Content-Type: application/json');
            echo json_encode($response);
        }
    }

    // =================================
    // Edycja załącznika ===============
    // =================================
    public function ajaxProcessUpdateAttachment() 
    {
        // Załaduj Model
        require_once(_PS_MODULE_DIR_ . _MKD_NAME_ . '/models/MKDProductAttachmentsModel.php');
            
        // Utwórz instancję modelu
        $model = new MKDProductAttachmentsModel();

        // Pobierz aktualną datę i godzinę
        $currentDateTime = date('Y-m-d H:i:s');

        $edit_ID = (int)Tools::getValue('attachmentId');

        $id_shop        = (int)Tools::getValue('shopId', Configuration::get('PS_SHOP_DEFAULT'));
        $product_id     = (int)Tools::getValue('productId');
        $type_id        = (int)Tools::getValue('groupId');
        $file_name      = Tools::getValue('attachmentName');

        $attachmentFile = $_FILES['attachmentFile'] ?? null;
        $attachmentURL  = Tools::getValue('attachmentURL') ? filter_var(Tools::getValue('attachmentURL'), FILTER_VALIDATE_URL) : null;

        $comment        = Tools::getValue('attachmentComment');
        $data_upd       = $currentDateTime;
        $active         = (int)Tools::getValue('active');


        // Pobierz Format pliku (value) dla danej grupy załączników w ścieżce 'upload_dir'
        $language_ID = Context::getContext()->language->id;
        $attachFormat = $model->getAttachmentFormatByTypeId($type_id, $language_ID);

        // Katalog docelowy, gdzie będą przechowywane załączniki
        $uploadDirectory = _PS_UPLOAD_DIR_ . 'attachments/product_' . $product_id . '/' . $attachFormat . '/';

        // Walidacja pliku/URL
        if ($attachmentFile && $attachmentFile['error'] === UPLOAD_ERR_OK) {

            if (!file_exists($uploadDirectory)) {
                mkdir($uploadDirectory, 0777, true);
            }    

            // Data pliku
            $currentTimestamp = time();
            $currentDate = date('d-m-Y');
            $fileNameNew = $currentDate . '_' . $currentTimestamp . '_' . $attachmentFile['name'];

            // Ścieżka docelowa
            $targetPath = $uploadDirectory . $fileNameNew;

            // Przesuń plik z folderu tymczasowego do docelowego folderu
            if (move_uploaded_file($attachmentFile['tmp_name'], $targetPath)) {
                
                // Plik został zapisany pomyślnie

                $file_url = $fileNameNew;

            } else {
                // Wystąpił błąd podczas zapisywania pliku
                $response = [
                    'success' => false,
                    'message' => Context::getContext()->getTranslator()->trans('There was an error saving')
                ];
            }

           
        }

        // Update załącznika
        if (Tools::getValue('action') === 'updateAttachment') {

            if (!file_exists($uploadDirectory)) {
                mkdir($uploadDirectory, 0777, true);
            }

            // 1. Pobierz dane z rekordu, który ma być update
            $attachmentToUpdate = Db::getInstance()->getRow('
            SELECT `file_name`, `file_url`, `comment`, `data_upd`, `active`
            FROM `' . _DB_PREFIX_ . MKDProductAttachmentsModel::$definition['table'] . '`
            WHERE `id` = ' . (int) $edit_ID . '
                AND `id_shop` = ' . (int) $id_shop . '
                AND `product_id` = ' . (int) $product_id .'
                AND `type_id` = ' . (int) $type_id      
            );


            if ($attachmentToUpdate) {
                // Sprawdź, które pole zostało zmienione
                $dataToUpdate = array();
                
                if ($file_name != $attachmentToUpdate['file_name']) {
                    $dataToUpdate['file_name'] = pSQL($file_name);
                }
                
                if ($comment != $attachmentToUpdate['comment']) {
                    $dataToUpdate['comment'] = pSQL($comment);
                }
                
                if ($attachmentFile) {
                    $dataToUpdate['file_url'] = $file_url;
                }
                
                if ($attachmentURL && $attachmentURL != $attachmentToUpdate['file_url']) {
                    $dataToUpdate['file_url'] = $attachmentURL;
                }
                
                if ($active != $attachmentToUpdate['active']) {
                    $dataToUpdate['active'] = (int)$active;
                }
                
                // Jeśli jakieś pole zostało zmienione, zaktualizuj rekord w bazie danych
                if (!empty($dataToUpdate)) {

                    $dataToUpdate['data_upd'] = $currentDateTime;
            
                    $result = Db::getInstance()->update(MKDProductAttachmentsModel::$definition['table'], $dataToUpdate, 'id = ' . (int)$edit_ID);

                    // Wyczyszczenie cache
                    $model->clearCache();

                    if ($result) {
                        $response = [
                            'success' => true,
                            'message' => Context::getContext()->getTranslator()->trans(
                                'The attachment was updated in the Group: %group_id%',
                                [
                                    '%group_id%' => $type_id
                                ]
                            )
                        ];

                    }
            
                }
            }
            

            // Zwróć odpowiedź JSON
            header('Content-Type: application/json');
            echo json_encode($response);

        }

    }


    // =================================
    // Usuwanie załącznika =============
    // =================================
    public function ajaxProcessDeleteAttachment()
    {

        // Załaduj Model
        require_once(_PS_MODULE_DIR_ . _MKD_NAME_ . '/models/MKDProductAttachmentsModel.php');
            
        // Utwórz instancję modelu
        $model = new MKDProductAttachmentsModel();

        $delete_ID = (int)Tools::getValue('attachmentId');

        $id_shop        = (int)Tools::getValue('shopId', Configuration::get('PS_SHOP_DEFAULT'));
        $product_id     = (int)Tools::getValue('productId');
        $type_id        = (int)Tools::getValue('groupId');

        // Pobierz dane z rekordu (position), który zostanie usunięty
        $positionToDelete = Db::getInstance()->getRow('
            SELECT `position`, `type_id`, `id_shop`, `product_id`, `file_url`
            FROM `' . _DB_PREFIX_ . MKDProductAttachmentsModel::$definition['table'] . '`
            WHERE `id` = ' . $delete_ID);


        $position   = (int) $positionToDelete['position'];
        $id_shop    = (int) $positionToDelete['id_shop'];
        $type_id    = (int) $positionToDelete['type_id'];
        $product_id = (int) $positionToDelete['product_id'];
        // Nazwa pliku do usunięcia
        $file_url   = $positionToDelete['file_url'];
        

        // Usuń załącznik
        if (Tools::getValue('action') === 'deleteAttachment') {
            
            // Ustaw dane w Modelu
            $model->id          = $delete_ID;
            $model->id_shop     = $id_shop;
            $model->product_id  = $product_id;
            $model->type_id     = $type_id;
            $model->file_url    = $file_url;
            

            // Usuń rekord
            $result = $model->delete($delete_ID);

            // Wyczyszczenie cache'u
            $model->clearCache();

            if ($result) {

                // 1. Zaktualizuj Pozycje rekordów w danej Grupie, Sklepie i produkcie
                Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . MKDProductAttachmentsModel::$definition['table'] . '`
                        SET `position` = `position` - 1
                        WHERE `id_shop` = ' . $model->id_shop . '
                                AND `type_id` = ' . $model->type_id . '
                                AND `product_id` = ' . $model->product_id . '
                                AND `position` > ' . $position);

                // 2. Pobierz Counter plików dla danej Grupy załączników w tabeli ..TYPES_SHOP
                $currentFilesCount = (int) Db::getInstance()->getValue('
                    SELECT `files` 
                    FROM `' . _DB_PREFIX_ . 'mkd_product_attachments_types_shop` 
                    WHERE `type_id` = ' . $model->type_id . ' 
                        AND `id_shop` = ' . $model->id_shop
                );

                // Zmniejsz liczbę plików o 1
                $deleteFilesCount = $currentFilesCount - 1;

                // Zaktualizuj Counter plików w danej Grupie
                Db::getInstance()->update(
                    'mkd_product_attachments_types_shop',
                    ['files' => $deleteFilesCount],
                    'type_id = ' . $model->type_id . ' AND `id_shop` = ' . $model->id_shop
                );

                // 3. Usuwanie pliku
                // Pobierz Format pliku (value) dla danej grupy załączników w ścieżce 'upload_dir'
                $language_ID = Context::getContext()->language->id;
                $attachFormat = $model->getAttachmentFormatByTypeId($model->type_id, $language_ID);

                // Katalog docelowy, gdzie będą przechowywane załączniki
                $uploadDirectory = _PS_UPLOAD_DIR_ . 'attachments/product_' . $model->product_id . '/' . $attachFormat . '/';

                // usuń plik
                $filePath = $uploadDirectory . $model->file_url;
                if (file_exists($filePath)) {
                    unlink($filePath);
                }
                

                // 4. Wyświetlić powiadomienie w Ajax
                $response = [
                    'success' => true,
                    'message' => Context::getContext()->getTranslator()->trans(
                        'The file "%file_name%" was deleted from the Group: %group_id%',
                        [
                            '%file_name%' => preg_replace('/^\d+-\d+-\d+_\d+_/', '', $model->file_url),
                            '%group_id%' => $model->type_id
                        ]
                    )
                ];

            } else {
                $response = [
                    'error' => true,
                    'message' => Context::getContext()->getTranslator()->trans('The attachment was deleted in the group') . ' [' .$type_id .']'
                ];
            }

            // Zwróć odpowiedź JSON
            header('Content-Type: application/json');
            echo json_encode($response);

        }
    }


}

