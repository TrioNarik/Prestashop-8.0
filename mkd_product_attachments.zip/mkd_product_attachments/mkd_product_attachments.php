<?php
/*
*
* Tworzenie instancji klasy "ProductExtraContent" dla każdej nowej zakładki w hooku displayProductExtraContent
*/


if (!defined('_PS_VERSION_')) {
    exit;
}

// Dostęp do oryginalnej klasy Zakładek/Tabs produktu: setTitle, setContent => tylko dla hook'a: displayProductExtraContent
use PrestaShop\PrestaShop\Core\Product\ProductExtraContent;


define('_MKD_NAME_', 'mkd_product_attachments');
define('_MKD_MODULE_NAME_', 'MKD - Product Attachments Management for user Groups');
define('_MKD_MODULE_DESC_', 'Attachments will be displayed with the on the Product Page - allows users to get the full information about the product. The module supports admins to upload many types of files and the unlimited number of attachments for each product.');
define('_MKD_MODULE_VERSION_', '3.6.5');
define('_MKD_CONTROLLER_IDENTIFIER_', _MKD_NAME_);
// Osobne renderForm() i renderTable()
define('_MKD_MODULE_COMPONENT_', ['types', 'programs']);


class MKD_product_attachments extends Module
{

    public function __construct()
    {

        $this->name = _MKD_NAME_;
        $this->tab = 'administration';
        $this->version = _MKD_MODULE_VERSION_;
        $this->author = 'GrupaFaro';
        $this->need_instance = 0;
        $this->default_language = Language::getLanguage(Configuration::get('PS_LANG_DEFAULT'));
        $this->id_shop = Context::getContext()->shop->id;
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->module_key = '09eesscc22c74b8081965099d989d13';

        parent::__construct();

        $this->bootstrap = true;
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall this module? All data will be deleted.');

        $this->displayName = _MKD_MODULE_NAME_;
        $this->description = _MKD_MODULE_DESC_;
        $this->image = 'logo.png';
    }


    public function install()
    {
        // 1. Wymagane tabele:
        require_once __DIR__ . '/sql/install.php';

        // 2. Wstaw przykładowe dane:
        require_once _PS_MODULE_DIR_ . _MKD_NAME_ . '/classes/MKDInstallerDefaultData.php';
        
        $installer = new MKDInstallerDefaultData($this->name);

        // Zainstaluj podstawowe hooki dla strony produktu
        $installer->installDefaultData('hooksProductPage', 'mkd_product_attachments_hooks');

        // Zainstaluj podstawowe formaty załączników
        $installer->installDefaultData('attachmentFormats', 'mkd_product_attachments_formats');
        
        // Czyszczenie cache
        Tools::clearCache();
        
        // 3. Rejestruj hooki
        return parent::install()
            && $this->registerHook('displayProductExtraContent') // Podstawowy do zakładek/Tabs na stronie produktu

            && $this->registerHook('displayProductActions')
            && $this->registerHook('displayAfterProductThumbs')
            && $this->registerHook('displayProductAdditionalInfo')
            && $this->registerHook('displayFooterProduct')

            // Hooki BO:
            // 1. dla załączników na stronie edycji produktu
            && $this->registerHook('displayAdminProductsExtra')
            // 2. do obsługi zapytań AJAX
            // && $this->registerHook('backOfficeHeader'); - przestarzały dla 8.0
            && $this->registerHook('displayBackOfficeHeader');

    }

    public function uninstall()
    {
        require_once __DIR__ . '/sql/uninstall.php';

        // Usuń dane dla kontrolera BO
        Configuration::deleteByName('AJAX_CONTROLLER');

        // Usuń folder "attachments" i jego zawartość
        $uploadDirectory = _PS_UPLOAD_DIR_ . 'attachments/';
        if (file_exists($uploadDirectory) && is_dir($uploadDirectory)) {
            $this->deleteDirectory($uploadDirectory);
        }

        // Czyszczenie cache
        Tools::clearCache();

        return parent::uninstall();
    }

    // Usuń folder z załącznikami
    private function deleteDirectory($dir)
    {
        if (!file_exists($dir)) {
            return true;
        }

        if (!is_dir($dir)) {
            return unlink($dir);
        }

        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }

            if (!$this->deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }

        return rmdir($dir);
    }
   

    // =============================================================================
    // ========================== HOOKI ============================================
    // =============================================================================
    public function hookDisplayProductExtraContent($params)
    {

        $hook_NAME = 'displayProductExtraContent';
        
        // Dodać do szablonu => inne #tabID
        $this->context->smarty->assign('hookName', $hook_NAME);

        $productExtraContents = array();

        // Tablice z danymi dla dodatkowych zakładek
        $extraTabsData = array(
            array(
                'title'     => $this->l('Download'),
                'content'   => $this->viewAttachmentsHook($hook_NAME, $params)
            ),
        );

        
        // Sprawdź, czy są grupy w danym hooku
        if ($this->viewAttachmentsHook($hook_NAME, $params)) {
            // Przetwarzanie danych zakładek tylko jeśli są grupy
            foreach ($extraTabsData as $tabData) {
                
                // Stwórz instancję klasy ProductExtraContent i ustaw tytuł oraz treść
                $productExtraContent = new ProductExtraContent();

                $productExtraContent->setTitle($tabData['title']);
                $productExtraContent->setContent($tabData['content']);

                $productExtraContents[] = $productExtraContent;
            }
        }

        return $productExtraContents;
    }

   
    public function hookDisplayProductActions($params)
    {

        $hook_NAME = 'displayProductActions';

        // Dodać do szablonu => inne #tabID
        $this->context->smarty->assign('hookName', $hook_NAME);
        
        return $this->viewAttachmentsHook($hook_NAME, $params);

    }


    public function hookDisplayAfterProductThumbs($params)
    {
        
        $hook_NAME = 'displayAfterProductThumbs';

        // Dodać do szablonu => inne #tabID
        $this->context->smarty->assign('hookName', $hook_NAME);
        
        return $this->viewAttachmentsHook($hook_NAME, $params);
      
    }

    public function hookDisplayProductAdditionalInfo($params)
    {

        $hook_NAME = 'displayProductAdditionalInfo';

        // Dodać do szablonu => inne #tabID
        $this->context->smarty->assign('hookName', $hook_NAME);
        
        return $this->viewAttachmentsHook($hook_NAME, $params);
      
    }

    public function hookDisplayFooterProduct($params)
    {
        $hook_NAME = 'displayFooterProduct';

        // Dodać do szablonu => inne #tabID
        $this->context->smarty->assign('hookName', $hook_NAME);
        
        return $this->viewAttachmentsHook($hook_NAME, $params);

    }


    //===========================
    // Product Edit Page Hook ===
    //===========================
    public function hookDisplayAdminProductsExtra($params)
    {

        // Pobierz ID edytowanego produktu
        $product_ID = (int) $params['id_product'];
        

        // Pobierz obiekt produktu
        $product = new Product($product_ID);

        if (Validate::isLoadedObject($product)) {

            // Kontroler Groups Config => Modal Form i Table:
            require_once _PS_MODULE_DIR_ . _MKD_NAME_. '/controllers/admin/ProductExtraAttachController.php';

            $controller = new ProductExtraAttachController();
            $controller->initForm($product_ID);

            // Renderuj szablon 
            return $this->display(__FILE__, 'views/templates/admin/product_extra_form.tpl');
        }

    }

    //=====================================================
    // AJAX BO Hook   =========== controller....&ajax=1 ===
    //=====================================================
    public function hookDisplayBackOfficeHeader()
    {
        Configuration::updateValue('AJAX_CONTROLLER', 'ProductExtraAttach');

        Media::addJsDef(array(
            'hookBackOfficeHeader_attachments' => array(
                // do obsługi ajax na stronie edycji produktu
                'ajaxUrl'               => $this->context->link->getAdminLink(Configuration::get('AJAX_CONTROLLER'), true) . '&ajax=1',

                // do walidacji .exe i rozmiarów przesyłanych plików w formularzu
                'jsonSampleDataFile'    => __PS_BASE_URI__ . 'modules/' . _MKD_NAME_ . '/SampleDataDefault.json'
            )
        ));
    }


    
    // =============================================================================
    // ========================== KONFIGURACJA MODUŁU ==============================
    // =============================================================================  
    public function getContent()
    {
        $output = '';

        // Kontroler Groups Config => Form i Table:
        require_once _PS_MODULE_DIR_ . _MKD_NAME_. '/controllers/admin/AdminModuleConfigFormController.php';

        // Kontroler Programs Config => Form i Table:
        require_once _PS_MODULE_DIR_ . _MKD_NAME_. '/controllers/admin/AdminProgramsConfigFormController.php';
        
        // 1. Grupa załączników
        $adminController    = new AdminModuleConfigFormController();
        $adminController->postProcess();


        if (Tools::isSubmit('add_group_type')) {
            
            // Renderuj Formularz dla Typów załączników
            $output .= $adminController->renderTypesForm();

        } elseif (Tools::isSubmit('update' . _MKD_MODULE_COMPONENT_[0])) {

            $editId = (int) Tools::getValue('id');
            $output .= $adminController->renderTypesForm($editId);

        
        } else {

            $output .= $adminController->renderTypesTable();

            // Przycisk dodawania nowej Grupy załączników (type)
            $output .= '<a href="' . $this->context->link->getAdminLink('AdminModules', true) . '&configure=' . $this->name . '&add_group_type" class="btn btn-primary">';
            $output .= $this->l('Add New Group') . '</a>';
            $output .= '<hr />';

        }

        // 2. Programy dla załączników
        $programsController = new AdminProgramsConfigFormController();
        $programsController->postProcess();
              

        if (Tools::isSubmit('add_program')) {
            
            $output .= $programsController->renderProgramsForm();
        }

        if (Tools::isSubmit('update' . _MKD_MODULE_COMPONENT_[1])) { {

            $editId = (int) Tools::getValue('id');
            $output .= $programsController->renderProgramsForm($editId);

            }
        }

        $output .= $programsController->renderProgramsTable();

        // Przycisk dodawania nowego Programu
        $output .= '<a href="' . $this->context->link->getAdminLink('AdminModules', true) . '&configure=' . $this->name . '&add_program" class="btn btn-primary">';
        $output .= $this->l('Add New program') . '</a>';
        $output .= '<hr />';
        

        return $output;
    }


    // =============================================================================
    // ====== WYŚWIETLANIA ZAŁĄCZNIKÓW W HOOKACH NA STRONIE PRODUKTU ===============
    // =============================================================================
    private function viewAttachmentsHook($hook_NAME, $params)
    {
        // Załaduj Manager załączników dla danego produktu:
        require_once _PS_MODULE_DIR_ . _MKD_NAME_ . '/classes/MKDFrontAttachmentsProductManager.php';
        $frontViewerManager = new MKDFrontAttachmentsProductManager();

        // Pobierz ID sklepu
        $shop_ID = (int) Context::getContext()->shop->id;

        // Pobierz Lang sklepu
        $lang_ID = (int) Context::getContext()->language->id;

        // Pobierz wszystkie dostępne grupy użytkowników w PS
        $userGroups = Group::getGroups($lang_ID);
        $userGroupsNames = array();
        foreach ($userGroups as $group) {
            $userGroupsNames[] = $group['name'];
        }

        if (isset($params['product'])) {
            $product_ID = (int) $params['product']->id;

            $downloadPath = __PS_BASE_URI__ . 'upload/attachments/product_' . $product_ID;

            // Pobierz listę załączników dla produktu
            $attachments = $frontViewerManager->getAttachmentsForProduct($hook_NAME, $product_ID, $shop_ID, $lang_ID, 'position', 'ASC');

            // Sprawdź, czy istnieją załączniki
            if (!empty($attachments)) {
                // Przekaż dane do szablonu
                $this->context->smarty->assign([
                    'attachments' => $attachments,
                    'downloadPath' => $downloadPath,
                    'allUserGroups' => $userGroupsNames
                ]);

                return $this->display(__FILE__, 'views/templates/hook/product_attachments.tpl');
            }
        }
    }




}
